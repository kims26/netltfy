package com.example.demo_product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
