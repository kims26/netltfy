package com.example.demo_product.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OwnerVo {
    
    int o_idx;
    String o_name;
    String o_addr;
    String o_tel;
    String o_id;
    String o_pwd;



}
