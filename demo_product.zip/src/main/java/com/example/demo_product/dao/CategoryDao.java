package com.example.demo_product.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo_product.vo.CategoryVo;



@Mapper
public interface CategoryDao {
    
      public List<CategoryVo> selectList();


     



        
}
